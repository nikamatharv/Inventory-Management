package com.inventory.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.web.bind.annotation.*;

import com.inventory.entity.InventoryItem;
import com.inventory.entity.QuantityUpdateRequest;
import com.inventory.service.InventoryService;

import java.util.List;

@RestController
@RequestMapping("/api/inventory")
public class InventoryController {

    @Autowired
    private InventoryService inventoryService;

    @Autowired
    private SimpMessagingTemplate messagingTemplate;

    @PostMapping
    public InventoryItem addInventoryItem(@RequestBody InventoryItem item) {
        InventoryItem savedItem = inventoryService.addItem(item);
        messagingTemplate.convertAndSend("/topic/inventory", savedItem);
        return savedItem;
    }

    @PutMapping("/{itemId}")
    public InventoryItem updateInventoryQuantity(@PathVariable Long itemId, @RequestBody QuantityUpdateRequest quantityUpdateRequest) {
        // Validate input
        if (quantityUpdateRequest.getQuantity() < 0) {
            throw new IllegalArgumentException("Quantity cannot be negative.");
        }
        // Update inventory
        InventoryItem updatedItem = inventoryService.updateItemQuantity(itemId, quantityUpdateRequest.getQuantity());
        
        // Send real-time update via WebSocket
        messagingTemplate.convertAndSend("/topic/inventory", updatedItem);
        
        return updatedItem;
    }


    @DeleteMapping("/{itemId}")
    public void deleteInventoryItem(@PathVariable Long itemId) {
        inventoryService.deleteItem(itemId);
        messagingTemplate.convertAndSend("/topic/inventory", "Item with ID " + itemId + " deleted.");
    }

    @GetMapping
    public List<InventoryItem> getAllInventoryItems(@RequestParam(required = false) String supplier,
                                                    @RequestParam(required = false) Boolean lowStock) {
        return inventoryService.getAllItems(supplier, lowStock);
    }
}

