package com.inventory.entity;

public class QuantityUpdateRequest {
    private int quantity;

    // Getter and Setter
    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}

