package com.inventory.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.inventory.entity.InventoryItem;

import java.util.List;

@Repository
public interface InventoryRepository extends JpaRepository<InventoryItem, Long> {
    List<InventoryItem> findBySupplierDetailsContaining(String supplier);
    List<InventoryItem> findByQuantityLessThanEqual(int threshold);
}

