package com.inventory.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.inventory.entity.InventoryItem;
import com.inventory.repository.InventoryRepository;

import java.util.List;
import java.util.Optional;

@Service
public class InventoryService {

    @Autowired
    private InventoryRepository inventoryRepository;

    public InventoryItem addItem(InventoryItem item) {
        return inventoryRepository.save(item);
    }

    public InventoryItem updateItemQuantity(Long itemId, int quantity) {
        Optional<InventoryItem> optionalItem = inventoryRepository.findById(itemId);
        if (optionalItem.isPresent()) {
            InventoryItem item = optionalItem.get();
            item.setQuantity(quantity);
            return inventoryRepository.save(item);
        } else {
            throw new RuntimeException("Item not found with ID: " + itemId);
        }
    }

    public void deleteItem(Long itemId) {
        if (inventoryRepository.existsById(itemId)) {
            inventoryRepository.deleteById(itemId);
        } else {
            throw new RuntimeException("Item not found with ID: " + itemId);
        }
    }

    public List<InventoryItem> getAllItems(String supplier, Boolean lowStock) {
        if (supplier != null) {
            return inventoryRepository.findBySupplierDetailsContaining(supplier);
        } else if (lowStock != null && lowStock) {
            return inventoryRepository.findByQuantityLessThanEqual(10); // Example threshold
        }
        return inventoryRepository.findAll();
    }
}

