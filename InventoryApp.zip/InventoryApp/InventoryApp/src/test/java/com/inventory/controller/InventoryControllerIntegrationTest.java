package com.inventory.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.inventory.entity.InventoryItem;
import com.inventory.entity.QuantityUpdateRequest;
import com.inventory.repository.InventoryRepository;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class InventoryControllerIntegrationTest {

    @Autowired
    private TestRestTemplate restTemplate;

    @Autowired
    private InventoryRepository inventoryRepository;

    private InventoryItem testItem;

    @BeforeEach
    void setup() {
        inventoryRepository.deleteAll();
        testItem = new InventoryItem();
        testItem.setItemName("Laptop");
        testItem.setQuantity(15);
        testItem.setSupplierDetails("ABC Supplier");
        inventoryRepository.save(testItem);
    }

    @Test
    void testAddInventoryItem() {
        InventoryItem newItem = new InventoryItem();
        newItem.setItemName("Mouse");
        newItem.setQuantity(20);
        newItem.setSupplierDetails("XYZ Supplier");

        ResponseEntity<InventoryItem> response = restTemplate.postForEntity("/api/inventory", newItem, InventoryItem.class);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("Mouse", response.getBody().getItemName());
    }

    @Test
    void testUpdateInventoryQuantity() {
        QuantityUpdateRequest request = new QuantityUpdateRequest();
        request.setQuantity(25);

        ResponseEntity<InventoryItem> response = restTemplate.exchange(
                "/api/inventory/" + testItem.getItemId(), HttpMethod.PUT, new HttpEntity<>(request), InventoryItem.class);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(25, response.getBody().getQuantity());
    }

    @Test
    void testDeleteInventoryItem() {
        restTemplate.delete("/api/inventory/" + testItem.getItemId());
        assertFalse(inventoryRepository.existsById(testItem.getItemId()));
    }

    @Test
    void testGetAllInventoryItems() {
        ResponseEntity<InventoryItem[]> response = restTemplate.getForEntity("/api/inventory", InventoryItem[].class);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertTrue(response.getBody().length > 0);
    }
}
